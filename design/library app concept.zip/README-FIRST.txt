Credits :

1. IOS 7 icons from Pixeden - http://www.pixeden.com
2. Teehan + Lax for IOS7 app bar - http://www.teehanlax.com
3. App icon (excluding the Digital library text) from Mapbox under BSD license - https://www.iconfinder.com/iconsets/maki#readme
4. Android UI Kit from Taylor Ling - http://androiduiux.com/2014/01/10/android-ui-design-kit-for-photoshop-4-4-free-download/

5. Book covers from Book Cover Archive - www.bookcoverarchive.com


Fonts used :

1. Lato - http://www.fontsquirrel.com/fonts/lato
2. Proxima Nova
3. Alike - http://www.1001freefonts.com/alike.font


Usage Instructions : 

You can modify the PSDs in anyway you like, for both commercial and non-commercial purposes. Book cover images are not included for copyright reasons but you can view them from www.bookcoverarchive.com. The book cover containers are smart objects and you can place your own images. They are denoted by the RED eye layer marker.


Don't forget to explore other designs by SAKWA DESIGN STUDIO :

Like on Facebook - http://www.facebook.com/sakwadesign.com
Website : www.sakwadesign.com
behance : behance.net/sakwadesignstudio

Looking for a user interface craftsman? You can reach me via email : info@sakwadesign.com 

 
